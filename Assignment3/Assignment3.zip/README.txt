To Compile Program Enter:
    gcc smallsh2.c -Wall -D_POSIX_C_SOURCE -std=c99 -o smallsh2
To Run Grading Script:
    p3testscript 2>&1
        or
    p3testscript 2>&1 | more

Important:
    Grading script must be in same directory as smallsh 

