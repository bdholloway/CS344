For Grading TA:
    The program runs fine about 80 percent of the time but sometimes the 20 point decrypted ciphertext1 question 
    returns a still encrypted line of text. Also the 5 point question comparing plaintext1 to plaintext1a Also
    seems to work only about 75 percent of the time. I could not find the error and did not want to futher dmaage
    things, especially if it runs for full points most of the time. I urge you to run the code several time to see
    that it indeed does work. 